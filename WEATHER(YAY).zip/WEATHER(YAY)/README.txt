1. Install ganache and launch ganache 

2. Copy the private key of first account in ganache and go to META MASK and import new wallet with the private key

3. If ETH amount is 0, go to add network manually, add new network :

	Network name: Ganache
	New RPC URL: HTTP://127.0.0.1:7545
	Chain ID: 1337
	Currency symbol: ETH

 After add new network ,switch the network to Ganache 


4. Create new folder and copy its directory and open it in command prompt

5. Enter npm install express (after using this command, there should be 3 items in the folder)

6. Copy and paste sky.jpg, UI.html ,api.py, oracle.sol and server.js into the folder

7. Open remix and upload the oracle.sol, switch the environment to Ganache Provider and change HTTP://127.0.0.1:8545 to HTTP://127.0.0.1:7545

8. Copy the first address of Ganache and paste into my_address="" in api.py

9. Deploy oracle.sol and copy abi and contract address, paste into api.py (abi= and contract_address="") and UI.html (const ABI = ; and const Address = '';)

10. In server.js , define route to serve UI.html : res.sendFile(path.join(__dirname + "/UI.html"));

11. Open terminal in vs code, enter node server.js

12. if success, go to browser and type 127.0.0.1:5000 and the interface will be loaded in the browser

13. Run api.py

14. Click connect to META MASK 

15. Click connect to ORACLE 

16. Choose location and choose a date 

17. Click search and wait for 20s (safety range to get data within 20s)





