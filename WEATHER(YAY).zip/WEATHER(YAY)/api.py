import pip


try:
    import requests
except ImportError:
    pip.main(['install', 'requests'])
    import requests

try:
    from web3 import Web3
except ImportError:
    pip.main(['install','web3'])
    from web3 import Web3




#first address in ganache
my_address="0x709042c5Cd8D387ab726Cb867629408cB8FFec38"
#your abi in the solidity
abi=[
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": False,
		"inputs": [
			{
				"indexed": False,
				"internalType": "string",
				"name": "latitude",
				"type": "string"
			},
			{
				"indexed": False,
				"internalType": "string",
				"name": "longitude",
				"type": "string"
			},
			{
				"indexed": False,
				"internalType": "string",
				"name": "date",
				"type": "string"
			}
		],
		"name": "requestdata",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "UvLvl",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_latitude",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_longitude",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_date",
				"type": "string"
			}
		],
		"name": "emitrequest",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "date",
				"type": "string"
			}
		],
		"name": "parseDate",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "pure",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "rainLvl",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "returnArray",
		"outputs": [
			{
				"components": [
					{
						"internalType": "string",
						"name": "latitude",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "longitude",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "date",
						"type": "string"
					},
					{
						"internalType": "uint256",
						"name": "temp_max",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "temp_min",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "uv",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "precipprob",
						"type": "uint256"
					}
				],
				"internalType": "struct Oracle.weather[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "returnRepu",
		"outputs": [
			{
				"internalType": "uint256[]",
				"name": "",
				"type": "uint256[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "returnfinal",
		"outputs": [
			{
				"components": [
					{
						"internalType": "string",
						"name": "latitude",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "longitude",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "date",
						"type": "string"
					},
					{
						"internalType": "uint256",
						"name": "temp_max",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "temp_min",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "uv",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "precipprob",
						"type": "uint256"
					}
				],
				"internalType": "struct Oracle.weather",
				"name": "",
				"type": "tuple"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_latitude",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_longitude",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_date",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_temp_max",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_temp_mix",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_uv",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "_precipprob",
				"type": "uint256"
			}
		],
		"name": "setWeather",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "weatherSig",
		"outputs": [
			{
				"internalType": "string",
				"name": "",
				"type": "string"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
]
#contract address
contract_address="0x23df0d250629DA5F6e54Bd5858EE7b80E0C8f4a7"
#ganache
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:7545"))

#connect to solidity
oracle=w3.eth.contract(address=contract_address,abi=abi)
# Send the GET request
def url_1(url1):

    response = requests.get(url1)

    if response.status_code==200:
        data = response.json()
        daily_time = data['forecast']['forecastday'][0]['date']
        temperature_max = data['forecast']['forecastday'][0]['day']['maxtemp_c']
        temperature_min = data['forecast']['forecastday'][0]['day']['mintemp_c']
        uv_index_max = data['forecast']['forecastday'][0]['day']['uv']
        precipitation_probability_max = data['forecast']['forecastday'][0]['day']['daily_chance_of_rain']
    
        return daily_time, temperature_max, temperature_min, uv_index_max, precipitation_probability_max     
    else:
        print("Error:", response.status_code)
        print(response.text)  # Print the error response body

def url_2(url2):

    response = requests.get(url2)

    if response.status_code==200:
        data = response.json()
        daily_time = data['days'][0]['datetime']
        temperature_max = data['days'][0]['tempmax']
        temperature_min = data['days'][0]['tempmin']
        uv_index_max = data['days'][0]['uvindex']
        precipitation_probability_max = data['days'][0]['precipprob']
       
        return daily_time, temperature_max, temperature_min, uv_index_max, precipitation_probability_max           
    else:
        print("Error:", response.status_code)
        print(response.text)  # Print the error response body
  
def url_3(url3):
    #url3
    # Check if the request was successful

    response = requests.get(url3)

    if response.status_code == 200:
        data = response.json()

        daily_time = data['daily']['time'][0]
        temperature_max = data['daily']['temperature_2m_max'][0]
        temperature_min = data['daily']['temperature_2m_min'][0]
        uv_index_max = data['daily']['uv_index_max'][0]
        precipitation_probability_max = data['daily']['precipitation_probability_max'][0]
        
        return daily_time, temperature_max, temperature_min, uv_index_max, precipitation_probability_max
    else:
        print("Error:", response.status_code)
        print(response.text)  # Print the error response body

def sendTransaction():
	latitude=event['args']['latitude']
	longtitude=event['args']['longitude']
	# Get date
	today_date = event['args']['date']

# Format the date to yyyy-mm-dd

	#Define the request URL and headers
	url1="https://api.weatherapi.com/v1/forecast.json?key=662174f4714c4854a91175128240105&q="+latitude+","+longtitude+"&days=1&aqi=no&alerts=yes&dt="+today_date
	url2="https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/%20"+latitude+"%2C%20"+longtitude+"/"+today_date+"?unitGroup=metric&key=X246HUMYGP4XBVQXT8V7BMLLL&contentType=json"
	url3="https://api.open-meteo.com/v1/forecast?latitude="+latitude+"&longitude="+longtitude+"&daily=temperature_2m_max,temperature_2m_min,uv_index_max,precipitation_probability_max&timezone=auto&start_date="+today_date+"&end_date="+today_date
	#use this address running the api

    #the step for transaction
    #1.build transaction
    #2.sign contract
    #3.send the transaction
    #by using tranact funtion can do the steps above in 1 time
	daily_time, temperature_max, temperature_min, uv_index_max, precipitation_probability_max = url_1(url1)
    
	ts_hash = oracle.functions.setWeather(latitude,longtitude,daily_time, int(temperature_max*100), int(temperature_min*100), int(uv_index_max*100), int(precipitation_probability_max*100)).transact({'from':my_address})
	print("Success send the data from url 1")

	daily_time, temperature_max, temperature_min, uv_index_max, precipitation_probability_max= url_2(url2)
	ts_hash = oracle.functions.setWeather(latitude,longtitude,daily_time, int(temperature_max*100), int(temperature_min*100), int(uv_index_max*100), int(precipitation_probability_max*100)).transact({'from':my_address})
	print("Success send the data from url 2")

	daily_time, temperature_max, temperature_min, uv_index_max, precipitation_probability_max = url_3(url3)
	ts_hash = oracle.functions.setWeather(latitude,longtitude,daily_time, int(temperature_max*100), int(temperature_min*100), int(uv_index_max*100), int(precipitation_probability_max*100)).transact({'from':my_address})
	print("Success send the data from url 3")



events=oracle.events.requestdata.create_filter(fromBlock='latest') #listen the event in blockchain

while True:#keep running and do the specific thing once have new event
	for event in events.get_new_entries(): 
		sendTransaction()